
export default function Home() {
  return (
    <div style={{fontFamily:'sans-serif',padding:'40px'}}>
      <h1>Wessex Fabrications Ltd</h1>
      <p>✅ Deployment successful</p>
      <p>I will now convert this into the full branded site for you.</p>
    </div>
  )
}
